import great_expectations as gx
import requests
context = gx.get_context()
dataPlatform="mysql"
url = f'http://localhost:8084/api/quality/processValidationResult/{dataPlatform}'
datasource = context.sources.add_sql(name="Health_Care", connection_string="mysql+pymysql://root:root@34.16.202.109:3115/Health_Care")
table_asset_providers = datasource.add_table_asset(name="providers_asset", table_name="Providers,"schema_name="Health_Care")
data_asset_providers = context.get_datasource("Health_Care").get_asset("providers_asset")
batch_request_providers = data_asset_providers.build_batch_request()
context.add_or_update_expectation_suite("expectation_suite_providers")
validator_providers = context.get_validator(batch_request=batch_request_providers,expectation_suite_name="expectation_suite_providers",)
validator_providers.expect_column_values_to_not_be_null(column="last_name")
validator_providers.expect_column_value_lengths_to_be_between("last_name", min_value=1, max_value=50)
validator_providers.expect_column_values_to_match_regex("last_name","^[A-Za-z0-9 ]+$")
validator_providers.expect_column_values_to_not_be_null(column="first_name")
validator_providers.expect_column_value_lengths_to_be_between("first_name", min_value=1, max_value=50)
validator_providers.expect_column_values_to_match_regex("first_name","^[A-Za-z0-9 ]+$")
validator_providers.save_expectation_suite(None,False)
checkpoint = context.add_or_update_checkpoint(name="my_quickstart_checkpoint", validator=validator_providers,)
checkpoint_result = checkpoint.run()
json_string = context.get_validation_result("expectation_suite_providers").to_json_dict()
response = requests.post(url, json=json_string)
print(response.text)
