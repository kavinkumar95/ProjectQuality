#!/bin/bash
unzip config.zip
# Loop through each .py file
for file in *.py; do
    # Run python3 command on each file
    python3 "$file"
done